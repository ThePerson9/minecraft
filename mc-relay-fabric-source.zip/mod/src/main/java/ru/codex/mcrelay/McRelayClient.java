package ru.codex.mcrelay;

import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientLifecycleEvents;
import net.minecraft.client.MinecraftClient;

public final class McRelayClient implements ClientModInitializer {
    public static final String RELAY_URL = "wss://minecraft-1-h7ml.onrender.com";

    @Override
    public void onInitializeClient() {
        ClientLifecycleEvents.CLIENT_STARTED.register(client ->
                client.execute(() -> MinecraftClient.getInstance().inGameHud.getChatHud()
                        .addMessage(net.minecraft.text.Text.literal("MC Relay loaded for 1.21.11"))));
    }
}
