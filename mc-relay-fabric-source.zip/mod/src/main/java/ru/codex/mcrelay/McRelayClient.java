package ru.codex.mcrelay;

import net.fabricmc.api.ClientModInitializer;

public final class McRelayClient implements ClientModInitializer {
    public static final String RELAY_URL = "wss://minecraft-1-h7ml.onrender.com";

    @Override
    public void onInitializeClient() {
        // Networking hooks will be added after the baseline build is verified.
    }
}
