package ru.codex.mcrelay;

import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientLifecycleEvents;
import net.minecraft.client.Minecraft;
import net.minecraft.network.chat.Component;

public final class McRelayClient implements ClientModInitializer {
    public static final String RELAY_URL = "wss://minecraft-1-h7ml.onrender.com";

    @Override
    public void onInitializeClient() {
        ClientLifecycleEvents.CLIENT_STARTED.register(client ->
                client.execute(() -> Minecraft.getInstance().gui.getChat()
                        .addMessage(Component.literal("MC Relay loaded for 1.21.11"))));
    }
}
